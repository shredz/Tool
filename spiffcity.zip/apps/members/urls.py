from django.conf.urls.defaults import *

urlpatterns = patterns('',
    (r'^signup/$', "spiffcity.apps.members.views.signup"),
    (r'^login/$' ,  "spiffcity.apps.members.views.login"),
    (r'^logout/$' ,  "spiffcity.apps.members.views.logout"),
    (r'^invite/$', "spiffcity.apps.members.views.invite"),
    (r'^settings/$', "spiffcity.apps.members.views.settings_view"),
    (r'^profile/$', "spiffcity.apps.members.views.profile"),
    (r'^v/(?P<code>(.*))/$', "spiffcity.apps.members.views.verify"),
    
    (r'^i/(?P<invid>([0-9a-zA-Z]*))/$', "spiffcity.apps.members.views.invitation_landing",{"name":"/"}),
    (r'^i/(?P<invid>([0-9a-zA-Z]*))/(?P<name>(.*))/$', "spiffcity.apps.members.views.invitation_landing"),
    
    (r'^like/(?P<deal_id>([0-9]*))/$', "spiffcity.apps.members.views.like_deal"),
    
    (r'^landed/$', "spiffcity.apps.members.views.landed"),
    
    #TODO NEXT LINES EXCEPT LAST ARE TEST AND ARE TO BE REMOVED FROM PRODUCTION
    (r'^test/$', "spiffcity.apps.members.views.test"),
    (r'^clc/$', "spiffcity.apps.members.views.clear_loc"),
    
    (r'^$', "spiffcity.apps.members.views.dashboard"),
)
