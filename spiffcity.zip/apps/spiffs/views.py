def index(request):
	pass

from spiffcity.apps.spiffs.models import *
from spiffcity.libs.utils import Response
from django.views.decorators.csrf import csrf_exempt

def deals (request,page):
	params = {'deals' : Deal.front_page(int(page)) }
	return Response.render("spiffs/deals.html" , params,request)

@csrf_exempt
def search(request):
	if request.method == "POST":
		keyword = request.POST['str']
		params = {'deals' : Deal.search(keyword) }
		return Response.render("spiffs/deals.html" , params,request)
		
