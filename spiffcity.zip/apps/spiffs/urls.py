from django.conf.urls.defaults import *

urlpatterns = patterns('',
    (r'^index/', "spiffcity.apps.spiffs.views.index"),
    
    (r'^search/$', "spiffcity.apps.spiffs.views.search"),
    (r'^deals/(?P<page>(.*))/$', "spiffcity.apps.spiffs.views.deals"),
)
