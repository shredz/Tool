from django.db import models
from django.contrib import admin
from django.db.models import Q

from spiffcity import settings
from spiffcity.apps.core.models import SpiffObject,SpiffTicket

import datetime



class UserDeal(models.Model):
	user				= models.ForeignKey('members.User')
	deal				= models.ForeignKey('spiffs.Deal')
	added				= models.DateTimeField(auto_now_add=True)
	
class Deal(SpiffObject):
	deal_id 			= models.CharField(max_length=30)
	advertiser_name 	= models.CharField(max_length=200)
	manufacturer_name 	= models.CharField(max_length=200)
	price 				= models.DecimalField(max_digits=10, decimal_places=2)
	value 				= models.DecimalField(max_digits=10, decimal_places=2)
	currency 			= models.CharField(max_length=30)
	deal_open 			= models.DateTimeField(db_index=True )
	deal_close 			= models.DateTimeField(db_index=True )
	expiration_date		= models.DateTimeField(db_index=True)
	sku 				= models.CharField(max_length=50)
	upc 				= models.CharField(max_length=50)
	catalog_id 			= models.CharField(max_length=30)
	purchase_url		= models.URLField(verify_exists=False, unique=True)
	is_free 			= models.BooleanField(default=False)	
	is_featured 		= models.BooleanField(default=False, db_index=True)

	def __unicode__(self):
		return self.title
    
	"""    
class Deal (SpiffObject):
	deal_open 			= models.DateTimeField(db_index=True)
	deal_close 			= models.DateTimeField(db_index=True)
	total_sold 			= models.IntegerField()
	price 				= models.DecimalField(max_digits=6, decimal_places=2)
	value 				= models.DecimalField(max_digits=6, decimal_places=2)
	is_free 			= models.BooleanField(default=False)	
	is_featured 		= models.BooleanField(default=False, db_index=True)
	highlights 			= models.TextField(null=True)
	fine_print 			= models.TextField()
	purchase_url 		= models.URLField(verify_exists=False)
	expiration_date 	= models.DateField()
	reward_points 		= models.IntegerField(default=0)
	
	
	markets = models.ManyToManyField('markets.Market', related_name='deals')
	merchant = models.ForeignKey('merchants.Merchant', related_name='deals', on_delete=models.PROTECT)
	redeem_locations = models.ManyToManyField('merchants.Location', related_name='locations')
	
	yelp_params = models.CharField(null=True, max_length=255)
	
	"""
	
	def is_valid(self):
		now = datetime.datetime.now()
		return now >= self.deal_open and now <= self.deal_close
	
	@staticmethod
	def assign_left(deals):
		now = datetime.datetime.now()
		
		ls = []
		
		for deal in deals:
			td = deal.expiration_date - now
			left = {}
			left["days"] = td.days
			left["hours"] = td.seconds / 3600
			left["mins"] = (td.seconds % 3600) / 60
			
			deal.left = left
			
			ls.append(deal)
		
		return ls
	
	@staticmethod
	def search(keyword):
		deals = Deal.objects.filter(Q(title__contains=keyword)| Q(description__contains=keyword))
		return Deal.assign_left(deals)
	
	@staticmethod
	def front_page(page):
		now = datetime.datetime.now()
		deals = Deal.objects.filter(expiration_date__gte = now, deal_open__lte=now, deal_close__gte = now).extra(order_by=['deal_open'])[(page-1)*6:(page*6)]
		return Deal.assign_left(deals)
		
	
	

admin.site.register(Deal)		

class Coupon(SpiffTicket):
	deal			= models.ForeignKey(Deal, related_name='coupons')
	title			= models.CharField(max_length=255)
	
	def is_expired(self):
		return datetime.date.today() > self.expiration_date
		

class ActivityType(models.Model):
	title 			= models.CharField(max_length=50)
	
	def __unicode__(self):
		return self.title

admin.site.register(ActivityType)


class RewardType(models.Model):
	title 			= models.CharField(max_length=50)
	
	def __unicode__(self):
		return self.title
	
class Reward(models.Model):
	reward_type		= models.ForeignKey(RewardType)
	activity		= models.ForeignKey('spiffs.Activity')
	


class Activity(models.Model):
	activity_type	= models.ForeignKey(ActivityType)
	user			= models.ForeignKey('members.User')
	added			= models.DateTimeField(auto_now_add=True)
		
	@staticmethod
	def get_delta_range(var,val):
		if var == "days":
			f = datetime.timedelta(days=val-1)
			t = datetime.timedelta(days=val)
		elif var == "months":
			f = datetime.timedelta(months=val-1)
			t = datetime.timedelta(months=val)
		
		return (f,t)
	
	@staticmethod
	def recent (user,limit):
		return Activity.objects.filter(user=user).extra(order_by=['added'])
		
	@staticmethod
	def chart(user,limit,sortby="days"):
		ls = {}
		now = datetime.datetime.now()
		for i in range(limit):
			time_range = Activity.get_delta_range(sortby,i)
			ls[now-time_range[0]]=Activity.objects.filter(user=user,added__gt=now-time_range[0],added__lte=now-time_range[1]).count()
		
		return ls

class SpiffActivity(Activity):
	userdeal		= models.ForeignKey(UserDeal)
	points			= models.DecimalField(max_digits=5, decimal_places=2)

