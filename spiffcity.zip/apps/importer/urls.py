from django.conf.urls.defaults import *

urlpatterns = patterns('',
    (r'^approval_list/$', "spiffcity.apps.importer.views.approval_list"),
    (r'^approve/(?P<p>([0-9]*))/$', "spiffcity.apps.importer.views.approve"),
 
    (r'^import_deals/', "spiffcity.apps.importer.views.import_deals"),
    
    (r'^$', "spiffcity.apps.importer.views.index"),    
)
