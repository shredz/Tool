from django.conf.urls.defaults import *

urlpatterns = patterns('',
    (r'^index/', "spiffcity.apps.reporting.views.index"),
)
