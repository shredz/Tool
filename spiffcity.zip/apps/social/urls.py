from django.conf.urls.defaults import *

urlpatterns = patterns('',
    (r'^index/', "spiffcity.apps.social.views.index"),
    (r'^facebook/connect', "spiffcity.apps.social.views.connect_to_facebook"),
    (r'^twitter/connect', "spiffcity.apps.social.views.connect_to_twitter"),
)
