from django.http import HttpResponseRedirect, HttpResponse
from django.contrib.auth import login as userlogin , get_backends 

from spiffcity.libs.social.facebook import Facebook 
from spiffcity.libs.social.twitter import Twitter 
from spiffcity import settings

from spiffcity.apps.geo.models import *
from spiffcity.apps.core.models import *
from spiffcity.apps.members.models import *
from spiffcity.apps.social.models import *

from spiffcity.libs.utils import ValueManager,Response
#from spiffcity.libs.social.libtwt import oauth2 as oauth
from oauth import oauth


import simplejson as json
import datetime

def index(request):
	pass

def connect_to_twitter(request):
	twt= Twitter(settings.CRED['TWITTER_CONSUMER_KEY'] ,settings.CRED['TWITTER_CONSUMER_SECRET'],settings.CRED['TWITTER_RETURN_URL'])
	
	try:
		verifier = request.GET['oauth_verifier']		
	except:
		return twt.connect_to_twitter(request)
	
	denied = request.GET.get('denied', None)
	if denied is None:		
		try:
			request_token = request.session['request_token']
		except:
			return twt.connect_to_twitter(request)
		
		token = oauth.OAuthToken.from_string(request_token)
		
		if token.key != request.GET.get('oauth_token', 'no-token'):
			del request.session ['request_token']
			return twt.connect_to_twitter(request)
		
		try:
			access_token = twt.get_access_token(token,verifier)
		except KeyError , e:
			return twt.connect_to_twitter(request)
			
		request.session['access_token'] = access_token.to_string()

		twt_user = twt.authenticate_twitter(access_token)
		return after_connect(request,twt_user,"twitter")				
	else:
		#message
		return HttpResponseRedirect("/members/")

def get_field(net_user,field,network):
	if network == "facebook":
		if field == "location":
			return net_user["location"]["name"]
		elif field == "username":
			return net_user["username"]
		elif field == "email":
			return net_user["email"]
		elif field == "first_name":
			return net_user["first_name"]
		elif field == "last_name":
			return net_user["last_name"]
		elif field == "gender":
			return net_user["gender"]
			
	elif network == "twitter":
		if field == "location":
			return net_user["location"]
		elif field == "username":
			return net_user["screen_name"]
		elif field == "email":
			return "None"
		elif field == "first_name":
			return net_user["name"]
		elif field == "last_name":
			return ""
		elif field == "gender":
			return ""
			
	return net_user[field]
			
def after_connect(request , net_user , network):
	try:
		account = Account.objects.get(uid=net_user['id'])
		backend = get_backends()[0]
		account.spiffuser.backend = "%s.%s" % (backend.__module__, backend.__class__.__name__)
		userlogin(request,account.spiffuser)
	except Account.DoesNotExist:
		needs_username_correction = False
		
		if request.user.is_authenticated():
			user = User.instance(request.user)
		else:
			country = Country.objects.get(id=1)
				
			phonenumber = PhoneNumber(
				countrycode = 0,
				carriercode = 0,
				number 		= 0,
			)
			phonenumber.save()
				
			address = Address(
				zipcode 		= '',
				street_line_1	= '',	
				street_line_2	= '',
				city			= '',
				state			= '',
				country			= country,
				location 		= country.location,
				phonenumebr		= phonenumber
			)
			
			try:
				loc = get_field(net_user,"location",network)
				address.street_line_1	= loc
				address.city			= loc
			except:
				pass
				
			address.save()
			
			username = get_field(net_user,"username",network)
			
			
			try:
				User.objects.get(username=username)
				username = get_field(net_user,"id",network)
				needs_username_correction = True
				request.session['needs_username_correction'] = True
			except:
				pass
			
			user = User (
				username		= username,
				email			= get_field(net_user,"email",network),
				password		= "0000",
				first_name		= '',
				last_name		= '',
				dob				= datetime.datetime.now(),
				gender			= '',
				address			= address,
				verification	= User.create_verification("1",True),
				is_active		= True,
				is_staff		= True,
				points			= 0,
			)
			
			try:
				user.first_name		= get_field(net_user,'first_name',network),
				user.last_name		= get_field(net_user,'last_name',network),
				user.gender			= ValueManager.translate_gender(get_field(net_user,'gender',network))
			except:
				pass
			
			user.save()
			
			backend = get_backends()[0]
			user.backend = "%s.%s" % (backend.__module__, backend.__class__.__name__)
			userlogin(request,user)
		
		account = Account(
			uid					= get_field(net_user,'id',network),
			oauth_token			= "",
			oauth_token_secret	= "",
			other_data			= json.dumps(net_user),
			spiffuser			= user,
			account_type		= network
		)
		
		account.save()
		
		if needs_username_correction:
			return HttpResponseRedirect("/members/profile/")		
			
	return HttpResponseRedirect("/members/")
	
	

def connect_to_facebook(request):
	fb = Facebook(settings.CRED['FACEBOOK_APP_ID'] ,settings.CRED['FACEBOOK_APP_SECRET'],settings.CRED['FACEBOOK_RETURN_URL'])
	
	try:
		code = request.GET['code']
	except:
		return fb.connect_to_facebook(request)
		
	request.session['token'] = code
	return after_connect(request,fb.authenticate_facebook(request,code),"facebook")
