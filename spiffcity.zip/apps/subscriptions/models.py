from django.db import models

class subscription(models.Model):
	pass
