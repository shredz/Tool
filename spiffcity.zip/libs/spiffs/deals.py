class DealSystem:
	def buy_deal(self,user,deal)		
		ud = UserDeal(user=user, deal=deal)
		ud.save()
		at = ActivityType.objects.get(title="BOUGHT_DEAL")
		sa = SpiffActivity(user=user,activity_type=at,userdeal=ud,points=deal.points)
		sa.save()
		self.award_points(sa)
		
	
