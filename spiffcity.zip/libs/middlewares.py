from django.http import HttpResponseRedirect, HttpResponse

class DomainMiddleware:
	def process_request(self, request):
		if request.get_host() == 'localhost':
			url = "http://192.168.1.143"+request.path
			if request.META['QUERY_STRING'] is not None:
				url = url + "?"+ request.META['QUERY_STRING']
			return HttpResponseRedirect(url)		
