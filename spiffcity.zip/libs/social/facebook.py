from django.http import HttpResponseRedirect, HttpResponse
from spiffcity.libs.utils import Exporter
from spiffcity import settings

import urllib, simplejson as json, cgi

class Facebook(Exporter):
	
	def __init__(self, fb_app_id,fb__app_secret,return_url):
		Exporter.__init__(self)

		self.fb_app_id = fb_app_id
		self.fb__app_secret =fb__app_secret
		self.return_url = return_url
	
	def connect_to_facebook(self,request):
		args = {
			'client_id': self.fb_app_id,
			'redirect_uri': self.return_url,
			'scope': 'email,publish_stream,user_birthday,friends_birthday,user_events,user_status,read_stream,offline_access',
		}
		return HttpResponseRedirect('https://www.facebook.com/dialog/oauth?' + urllib.urlencode(args))
	
	def get_access_token(self,token):
		args = {
			'client_id': self.fb_app_id,
			'client_secret': self.fb__app_secret,
			'redirect_uri': self.return_url,
			'code': token,
		}

		target = urllib.urlopen('https://graph.facebook.com/oauth/access_token?' + urllib.urlencode(args)).read()
		response = cgi.parse_qs(target)
		return response['access_token'][-1]
	
	def news_feed(self,access_token):
		
	
	def authenticate_facebook (self,request , token):
		access_token = self.get_access_token(token)
		fb_profile = json.loads(urllib.urlopen('https://graph.facebook.com/me?' + urllib.urlencode(dict(access_token=access_token))).read())
		request.session['access_token'] = access_token
		fb_profile['access_token'] = access_token

		return fb_profile
        
