from libtwt import oauthtwitter2 as oauthtwitter

from django.http import HttpResponseRedirect , HttpResponse

class Twitter:
	def __init__(self,twt_app_key, twt_app_secret, return_url):
		self.twt_app_key = twt_app_key
		self.twt_app_secret = twt_app_secret
		self.return_url = return_url
		
	def connect_to_twitter(self,request):
	
		twt = oauthtwitter.TwitterOAuthClient(self.twt_app_key, self.twt_app_secret)
		request_token = twt.fetch_request_token(callback = self.return_url)    
		request.session['request_token'] = request_token.to_string()	
		return HttpResponseRedirect(twt.authorize_token_url(request_token))
	
	def authenticate_twitter(self,twitter_access_token):
		twitter = oauthtwitter.TwitterOAuthClient(self.twt_app_key, self.twt_app_secret)
		tw_profile = twitter.get_user_info(twitter_access_token)  
		return tw_profile 
		
	def get_access_token(self,token, verifier):
		twt = oauthtwitter.TwitterOAuthClient(self.twt_app_key, self.twt_app_secret)
		return twt.fetch_access_token(token, verifier)
