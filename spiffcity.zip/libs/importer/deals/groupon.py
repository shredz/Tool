from spiffcity.libs.utils import Importer

class Groupon(Importer):
	def __init__(self):
		pass
		

