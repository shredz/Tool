from django.conf.urls.defaults import *

from django.contrib import admin
admin.autodiscover()

urlpatterns = patterns('',
    (r'^admin/doc/', 		include('django.contrib.admindocs.urls')),
    (r'^admin/', 			include(admin.site.urls)),
    (r'^members/', 			include("spiffcity.apps.members.urls")),
	(r'^importer/', 		include("spiffcity.apps.importer.urls")),
	(r'^reporting/', 		include("spiffcity.apps.reporting.urls")),
	(r'^social/', 			include("spiffcity.apps.social.urls")),
	(r'^spiffs/', 			include("spiffcity.apps.spiffs.urls")),
	(r'^(?P<p>(.*))/$', 	"spiffcity.views.page"),
	(r'^$', 				"spiffcity.views.index"),
)
